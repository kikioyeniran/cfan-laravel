<div class="footer py-4">
    <div class="container-fluid" style="padding-left: 30%;">
      <p>
      <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
      Copyright &copy; All rights reserved | <a href="#" target="_blank" >Creative Fingers art Nexus</a> |<a href="/login" target="_blank" > Admin </a>| <a href="http://www.crossplatform.com.ng" target="_blank" >By Cross Platform</a>
      <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
      </p>
    </div>
  </div>
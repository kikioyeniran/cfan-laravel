

<?php $__env->startSection('content'); ?>
<div class="" data-aos="fade">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row mb-5 site-section">
                        <div class="col-12 ">
                            <h2 class="site-section-heading text-center"><?php echo e(strtoupper($post->theme)); ?></h2>
                        </div>
                    </div>

                    <div class="row mb-5">
                        <div class="col-md-7">
                            <img src="<?php echo e(asset('/storage/pictures/' . $post->picture)); ?>" alt="Images" class="img-fluid">
                        </div>
                        <div class="col-md-4 ml-auto">
                            <h3><?php echo e(strtoupper($post->theme)); ?></h3>
                            <h3><?php echo e($post->location); ?></h3>
                            <h3><?php echo e($post->date); ?></h3>
                            <p><?php echo $post->description; ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-7">
                <div class="row mb-5">
                    <div class="col-12 ">
                    <h2 class="site-section-heading text-center">Event(Exhibition) Images</h2>
                    </div>
                </div>
            </div>

        </div>
        <div class="row" id="lightgallery">
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class="col-sm-6 col-md-4 col-lg-3 col-xl-2 item"
                data-download-url=false
                data-aos="fade" data-src="<?php echo e(asset("storage/pictures/$post->picture")); ?>"
                data-sub-html="<h4><?php echo e($post->description); ?></h4>">
                <a href="#">
                    <img src="<?php echo e(asset("storage/pictures/$post->picture")); ?>" alt="image" class="img-fluid" style="max-height: 250px;">
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cfan_laravel\resources\views/events/show.blade.php ENDPATH**/ ?>
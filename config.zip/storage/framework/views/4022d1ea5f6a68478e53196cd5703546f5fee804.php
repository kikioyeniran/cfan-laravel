

<?php $__env->startSection('content'); ?>
<div class="dashboard-ecommerce">
    <div class="container-fluid dashboard-content ">

        <!-- ============================================================== -->
        <!-- pageheader  -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Home</h2>
                    <p class="pageheader-text">Edit Company Details</p>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Company Details</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader  -->
        <!-- ============================================================== -->


        <div class="row">
         <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Edit Company Details</h5>
                <div class="card-body">
                    <?php echo Form::open(['action' => ['CompDetailsController@update', $post->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                <div class="form-group">
                                    <label for="inputText3" class="col-form-label">Email</label>
                                    <?php echo e(Form::text('email', $post->email, ['class' => 'form-control'])); ?>

                                </div>
                                <div class="form-group">
                                    <label for="inputText3" class="col-form-label">Phone Number(s)</label>
                                    <?php echo e(Form::text('phone', $post->phone_numbers, ['class' => 'form-control'])); ?>

                                </div>
                                <div class="form-group">
                                    <label for="inputText3" class="col-form-label">Company Address</label>
                                    <?php echo e(Form::text('address', $post->address, ['class' => 'form-control'])); ?>

                                </div>
                                <div class="form-group">
                                    <label for="inputText3" class="col-form-label">Facebook Link</label>
                                    <?php echo e(Form::text('fb_link', $post->fb_link, ['class' => 'form-control'])); ?>

                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                <div class="form-group">
                                    <label for="inputText3" class="col-form-label">Instagram Link</label>
                                    <?php echo e(Form::text('ig_link', $post->ig_link, ['class' => 'form-control'])); ?>

                                </div>
                                <div class="form-group">
                                    <label for="inputText3" class="col-form-label">Twitter Link</label>
                                    <?php echo e(Form::text('tw_link', $post->tw_link, ['class' => 'form-control'])); ?>

                                </div>
                                <div class="form-group">
                                    <label for="inputText3" class="col-form-label">Youtube Link</label>
                                    <?php echo e(Form::text('yt_link', $post->yt_link, ['class' => 'form-control'])); ?>

                                </div>
                                <label for="inputText3" class="col-form-label">Company Mission Image</label>
                                <div class="custom-file mb-3">
                                    <?php echo e(Form::file('comp_img', ['class'=> 'custom-file-input'])); ?>

                                    <br/>
                                    <label class="custom-file-label" for="customFile">Select Image</label>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="form-group">
                                    <label for="inputText3" class="col-form-label">C.F.A.N Mission Statement</label>
                                    <?php echo e(Form::textarea('mission', $post->mission, ['class' => 'form-control', 'placeholder' => 'Mission Statement...', 'rows' => 5, 'id' => 'summernote'])); ?>

                                </div>
                                <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                <?php echo e(Form::submit('Submit', ['class'=> 'btn btn-primary', 'id'=> 'prodSub'])); ?>

                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
         </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cfan_laravel\resources\views/comp_details/edit.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<div class="dashboard-ecommerce">
    <div class="container-fluid dashboard-content ">

        <!-- ============================================================== -->
        <!-- pageheader  -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">Home</h2>
                    <p class="pageheader-text">Edit Art Work</p>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Art Work</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader  -->
        <!-- ============================================================== -->


        <div class="row">
         <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="card">
                <h5 class="card-header">Edit Art Work</h5>
                <div class="card-body">
                    <?php echo Form::open(['action' => ['ArtWorksController@update', $post->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                <div class="form-group">
                                    <label for="inputText3" class="col-form-label">Art Category</label>
                                      <?php echo e(Form::select('category', $catOptions, $post->category_id, ['class'=>'form-control form-control-lg', 'id'=> 'category'])); ?>

                                </div>
                                <div class="form-group">
                                    <label for="inputText4" class="col-form-label">Artist</label>
                                    <?php echo e(Form::select('artist', $artOptions, $post->artist_id, ['class'=>'form-control form-control-lg'])); ?>

                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                <div class="form-group">
                                    <label for="inputText3" class="col-form-label">Measurement</label>
                                    <?php echo e(Form::text('measurement', $post->measurement, ['class' => 'form-control'])); ?>

                                </div>
                                <label for="inputText3" class="col-form-label">Art Work Image</label>
                                <div class="custom-file mb-3">
                                    <?php echo e(Form::file('art_img', ['class'=> 'custom-file-input'])); ?>

                                    <br/>
                                    <label class="custom-file-label" for="customFile">Select Art Work Image</label>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="form-group">
                                    <label for="inputText3" class="col-form-label">Art Description</label>
                                    <?php echo e(Form::textarea('description', $post->description, ['class' => 'form-control', 'placeholder' => 'Art Description...', 'rows' => 2])); ?>

                                </div>
                                <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                <?php echo e(Form::submit('Submit', ['class'=> 'btn btn-primary', 'id'=> 'prodSub'])); ?>

                            </div>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
         </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cfan_laravel\resources\views/artworks/edit.blade.php ENDPATH**/ ?>
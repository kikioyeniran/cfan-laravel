

<?php $__env->startSection('content'); ?>
<div class="container-fluid" data-aos="fade" data-aos-delay="500">
    <div class="swiper-container images-carousel">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="image-wrap">
                <div class="image-info">
                  <h2 class="mb-3">Abstract art</h2>
                  <a href="#" class="btn btn-outline-white py-2 px-4">More Art Works</a>
                </div>
                <img src="<?php echo e(asset('images/abstract.jpg')); ?>" alt="Image">
              </div>
            </div>
            <div class="swiper-slide">
              <div class="image-wrap">
                <div class="image-info">
                  <h2 class="mb-3">Wood Works</h2>
                  <a href="#" class="btn btn-outline-white py-2 px-4">More Art Works</a>
                </div>
                <img src="<?php echo e(asset('images/w02.jpg')); ?>" alt="Image">
              </div>
            </div>
            <div class="swiper-slide">
              <div class="image-wrap">
                <div class="image-info">
                  <h2 class="mb-3">Mixed Media</h2>
                  <a href="#" class="btn btn-outline-white py-2 px-4">More Art Works</a>
                </div>
                <img src="<?php echo e(asset('images/mixed.jpg')); ?>" alt="Image">
              </div>
            </div>
            <div class="swiper-slide">
              <div class="image-wrap">
                <div class="image-info">
                  <h2 class="mb-3">Portrait Painting</h2>
                  <a href="#" class="btn btn-outline-white py-2 px-4">More Art Works</a>
                </div>
                <img src="<?php echo e(asset('images/portrait.jpg')); ?>" alt="Image">
              </div>
            </div>
            <div class="swiper-slide">
              <div class="image-wrap">
                <div class="image-info">
                  <h2 class="mb-3">Wearable art</h2>
                  <a href="#" class="btn btn-outline-white py-2 px-4">More Art Works</a>
                </div>
                <img src="<?php echo e(asset('images/wearable.jpg')); ?>" alt="Image">
              </div>
            </div>
            <div class="swiper-slide">
              <div class="image-wrap">
                <div class="image-info">
                  <h2 class="mb-3">Wood Works</h2>
                  <a href="#" class="btn btn-outline-white py-2 px-4">More Art Works</a>
                </div>
                <img src="<?php echo e(asset('images/w03.jpg')); ?>" alt="Image">
              </div>
            </div>
            <div class="swiper-slide">
              <div class="image-wrap">
                <div class="image-info">
                  <h2 class="mb-3">abstract art</h2>
                  <a href="#" class="btn btn-outline-white py-2 px-4">More Art Works</a>
                </div>
                <img src="<?php echo e(asset('images/abstract2.jpg')); ?>" alt="Image">
              </div>
            </div>
        </div>

        <div class="swiper-pagination"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>
        <div class="swiper-scrollbar"></div>
    </div>
</div>
<br/><br>
<div class="container-fluid" data-aos="fade" data-aos-delay="500">
  <div class="row mb-5">
    <div class="col-12 ">
      <h2 class="site-section-heading text-center">Latest News</h2>
    </div>
  </div>
  <div class="card-deck">
    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
      <a href="news/<?php echo e($post->link); ?>"><img class="card-img-top" src="<?php echo e(asset('/storage/pictures/' . $post->picture)); ?>" alt="Card image cap" style="max-height: 300px;"></a>
      <div class="card-body">
        <a href="news/<?php echo e($post->link); ?>"><h5 class="card-title"><?php echo e($post->title); ?></h5></a>
        <p class="card-text"><?php echo e($post->summary); ?></p>
      </div>
      <div class="card-footer">
        <small class="text-muted">Last updated <?php echo e($post->updated_at); ?></small>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>


<div id="modal-content">
  <h2>Subscribe To Our Newsletter</h2>
  <label for="yurEmail">Your Email Adress:</label>
  <?php echo Form::open(['action' => 'NewsletterController@store', 'method' => 'POST']); ?>

    
    <?php echo e(Form::text('email', '', ['placeholder' => 'me@example.com', 'id' => 'yurEmail'])); ?>

    
    <?php echo e(Form::submit('Subscribe', ['class'=> 'button order-cheezburger'])); ?>

  <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cfan_laravel\resources\views/index.blade.php ENDPATH**/ ?>
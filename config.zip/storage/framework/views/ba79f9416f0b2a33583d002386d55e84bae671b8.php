<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>CFAN Admin</title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/favicon.png')); ?>">

    

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Crimson+Text:400,400i" rel="stylesheet">


    <!-- Styles -->
    
    
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link href="<?php echo e(asset('admin/assets/vendor/fonts/circular-std/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/libs/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/fonts/fontawesome/css/fontawesome-all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/charts/chartist-bundle/chartist.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/charts/morris-bundle/morris.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/charts/c3charts/c3.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/fonts/flag-icon-css/flag-icon.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/datepicker/tempusdominus-bootstrap-4.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/multi-select/css/multi-select.css')); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-main-wrapper">
        <?php echo $__env->make('admin.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="dashboard-wrapper">
            <?php echo $__env->make('admin.inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
            <?php echo $__env->make('admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>


    
    <!-- Scripts -->
    
    <script src="<?php echo e(asset('admin/assets/vendor/jquery/jquery-3.3.1.min.js')); ?>"></script>
    <!-- Autofill Dropdown JS -->
    

    <!-- bootstap bundle js -->
    <script src="<?php echo e(asset('admin/assets/vendor/bootstrap/js/bootstrap.bundle.js')); ?>"></script>
    <!-- slimscroll js -->
    <script src="<?php echo e(asset('admin/assets/vendor/slimscroll/jquery.slimscroll.js')); ?>"></script>

    <script>
        $(document).ready(function(){
          $("#myInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#myTable tr").filter(function() {
              $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
          });
        });
    </script>

    <!-- Multiselect js -->
    <script src="<?php echo e(asset('admin/assets/vendor/multi-select/js/jquery.multi-select.js')); ?>"></script>
    <script>
      $('#my-select, #pre-selected-options').multiSelect()
    </script>

    <!-- main js -->
    <script src="<?php echo e(asset('admin/assets/libs/js/main-js.js')); ?>"></script>
    <!-- chart chartist js -->
    <script src="<?php echo e(asset('admin/assets/vendor/charts/chartist-bundle/chartist.min.js')); ?>"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.js"></script>
    <script>
      $('#summernote').summernote({
        placeholder: 'Hello Bootstrap 4',
        tabsize: 2,
        height: 100
      });
    </script>

    
    <script src="<?php echo e(asset('admin/assets/libs/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    <!-- sparkline js -->
    <script src="<?php echo e(asset('admin/assets/vendor/charts/sparkline/jquery.sparkline.js')); ?>"></script>
    <!-- morris js -->
    <script src="<?php echo e(asset('admin/assets/vendor/charts/morris-bundle/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendor/charts/morris-bundle/morris.js')); ?>"></script>
    <!-- chart c3 js -->
    <script src="<?php echo e(asset('admin/assets/vendor/charts/c3charts/c3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendor/charts/c3charts/d3-5.4.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendor/charts/c3charts/C3chartjs.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/js/dashboard-ecommerce.js')); ?>"></script>
    <!-- datepicker -->
    <script src="<?php echo e(asset('admin/assets/vendor/datepicker/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendor/datepicker/tempusdominus-bootstrap-4.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendor/datepicker/datepicker.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\cfan_laravel\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <div class="site-section" data-aos="fade">
        <div class="container-fluid">

        <div class="row justify-content-center">

            <div class="col-md-7">
            <div class="row mb-5">
                <div class="col-12 ">
                <h2 class="site-section-heading text-center"><?php echo e($cat_name); ?></h2>
                </div>
            </div>
            </div>

        </div>
        <div class="row" id="lightgallery">
            <?php $__currentLoopData = $artworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class="col-sm-6 col-md-4 col-lg-3 col-xl-2 item"
                data-download-url=false
                data-aos="fade" data-src="<?php echo e(asset("storage/pictures/$post->picture")); ?>"
                data-sub-html="<h4><?php echo e($post->artist); ?></h4><h4><?php echo e($post->measurement); ?></h4><p><?php echo e($post->description); ?></p>">
                <a href="#">
                    <img src="<?php echo e(asset("storage/pictures/$post->picture")); ?>" alt="image" class="img-fluid" style="max-height: 250px;">
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cfan_laravel\resources\views/artworks/index.blade.php ENDPATH**/ ?>
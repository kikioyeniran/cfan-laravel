

<?php $__env->startSection('content'); ?>
<div class="" data-aos="fade">
    <div class="container-fluid">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="row mb-5 site-section"  style="padding-bottom: 10px;">
                        <div class="col-12 ">
                            <h2 class="site-section-heading text-center"><?php echo e(strtoupper($post->title)); ?></h2>
                        </div>
                    </div>

                    <div class="row mb-5">
                        <div class="col-md-12">
                            <img src="<?php echo e(asset('/storage/pictures/' . $post->picture)); ?>" alt="Images" class="img-fluid" style="border-top-left-radius: 2%; border-top-right-radius: 2%; width: 100%; max-height: 400px">
                        </div>

                        <div class="col-md-12">
                            <br>
                            <h3 style="padding-left: 40%"> BY <?php echo e(strtoupper($post->author)); ?></h3>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="row mb-5">
                        <div class="col-12 ">
                        <p><?php echo $post->details; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cfan_laravel\resources\views/news/show.blade.php ENDPATH**/ ?>
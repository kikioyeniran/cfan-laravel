

<?php $__env->startSection('content'); ?>
<div class="site-section"  data-aos="fade">
    <div class="container-fluid">

      <div class="row justify-content-center">
        <div class="col-md-11">
          <div class="row mb-5">
            <div class="col-12 ">
              <h2 class="site-section-heading text-center">Events and Exhibitions</h2>
            </div>
          </div>
          <div class="card-deck">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="card">
                        <img class="card-img-top" src="<?php echo e(asset('/storage/pictures/' . $post->picture)); ?>" alt="Card image cap" style="max-height: 300px;">
                        <div class="card-body">
                            <a href="events/<?php echo e($post->link); ?>"><h5 class="card-title"><?php echo e(strtoupper($post->theme)); ?></h5></a><hr/>
                            <p class="card-text"><?php echo e($post->location); ?> |<a href="events/<?php echo e($post->link); ?>" class="btn btn-outline-white py-2 px-4">View Event</a></p>

                            
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">Last updated <?php echo e($post->updated_at); ?></small>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cfan_laravel\resources\views/events/index.blade.php ENDPATH**/ ?>